"use strict";

const http = require("node:http");
const path = require("node:path");
const fs = require("node:fs/promises");
const crypto = require("node:crypto");

const PORT = Number(process.env.PORT) || 3000;
const HOST = process.env.HOST || "127.0.0.1";
const DATA_DIRECTORY = path.join(__dirname, "data");
const REQUESTS_FILE = path.join(DATA_DIRECTORY, "information-requests.json");
const MAX_BODY_SIZE = 32 * 1024;

function sendJson(response, statusCode, payload) {
    response.writeHead(statusCode, {
        "Content-Type": "application/json; charset=utf-8",
        "Cache-Control": "no-store",
        "Access-Control-Allow-Origin": process.env.CORS_ORIGIN || "*",
        "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type",
    });
    response.end(JSON.stringify(payload));
}

function normaliseEmail(value) {
    return typeof value === "string" ? value.trim().toLowerCase() : "";
}

function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && email.length <= 254;
}

async function readRequests() {
    try {
        const contents = await fs.readFile(REQUESTS_FILE, "utf8");
        const requests = JSON.parse(contents);
        return Array.isArray(requests) ? requests : [];
    } catch (error) {
        if (error.code === "ENOENT") return [];
        throw error;
    }
}

async function saveRequest(request) {
    await fs.mkdir(DATA_DIRECTORY, { recursive: true });
    const requests = await readRequests();
    requests.push(request);
    await fs.writeFile(REQUESTS_FILE, `${JSON.stringify(requests, null, 2)}\n`, "utf8");
}

function readBody(request) {
    return new Promise((resolve, reject) => {
        let body = "";

        request.setEncoding("utf8");
        request.on("data", (chunk) => {
            body += chunk;
            if (Buffer.byteLength(body, "utf8") > MAX_BODY_SIZE) {
                reject(Object.assign(new Error("Request body is too large."), { statusCode: 413 }));
                request.destroy();
            }
        });
        request.on("end", () => resolve(body));
        request.on("error", reject);
    });
}

async function handleInformationRequest(request, response) {
    let payload;

    try {
        payload = JSON.parse(await readBody(request));
    } catch (error) {
        return sendJson(response, error.statusCode || 400, {
            error: "invalid_request",
            message: error.statusCode === 413 ? error.message : "Request body must be valid JSON.",
        });
    }

    const email = normaliseEmail(payload.email);
    if (!isValidEmail(email)) {
        return sendJson(response, 422, {
            error: "invalid_email",
            message: "Please provide a valid email address.",
        });
    }

    const requestRecord = {
        id: crypto.randomUUID(),
        email,
        source: typeof payload.source === "string" ? payload.source.slice(0, 80) : "website",
        createdAt: new Date().toISOString(),
    };

    try {
        await saveRequest(requestRecord);
    } catch (error) {
        console.error("Unable to save information request:", error);
        return sendJson(response, 500, {
            error: "storage_error",
            message: "The request could not be saved. Please try again later.",
        });
    }

    return sendJson(response, 201, {
        message: "Your information request has been received.",
        id: requestRecord.id,
    });
}

const server = http.createServer(async (request, response) => {
    const requestUrl = new URL(request.url, `http://${request.headers.host || `${HOST}:${PORT}`}`);

    if (request.method === "OPTIONS") {
        return sendJson(response, 204, {});
    }

    if (request.method === "GET" && requestUrl.pathname === "/api/health") {
        return sendJson(response, 200, { status: "ok", service: "perennial-bridge-api" });
    }

    if (request.method === "POST" && requestUrl.pathname === "/api/information-requests") {
        return handleInformationRequest(request, response);
    }

    return sendJson(response, 404, { error: "not_found", message: "Route not found." });
});

server.on("error", (error) => {
    if (error.code === "EADDRINUSE") {
        console.error(`Port ${PORT} is already in use. The API may already be running.`);
        process.exit(1);
    }

    console.error("Unable to start the API:", error);
    process.exit(1);
});

server.listen(PORT, HOST, () => {
    console.log(`Perennial Bridge API listening at http://${HOST}:${PORT}`);
});

process.on("SIGTERM", () => server.close(() => process.exit(0)));
process.on("SIGINT", () => server.close(() => process.exit(0)));
