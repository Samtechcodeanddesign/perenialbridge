/* =========================================================
   THE PERENNIAL BRIDGE INITIATIVE
   MAIN WEBSITE JAVASCRIPT
   ========================================================= */

"use strict";

// Keep the full curriculum markup from index.html; an older revision listener
// attempts to replace the main content with a shortened version on load.
const mainInnerHTMLDescriptor = Object.getOwnPropertyDescriptor(Element.prototype, "innerHTML");
if (mainInnerHTMLDescriptor && mainInnerHTMLDescriptor.set) {
    Object.defineProperty(Element.prototype, "innerHTML", {
        configurable: true,
        get: mainInnerHTMLDescriptor.get,
        set(value) {
            if (this.matches && this.matches("body > main") && value.includes("Four Pathways to Wisdom and Service")) {
                return;
            }
            mainInnerHTMLDescriptor.set.call(this, value);
        }
    });
}

document.addEventListener("DOMContentLoaded", function () {
    var fullPathways = document.querySelector("#pathways .client-pathways");
    if (!fullPathways) return;
    fullPathways.querySelectorAll(".client-pathway").forEach(function (card) {
        if (card.querySelector(".client-link")) return;
        var link = document.createElement("a");
        link.className = "client-link";
        link.href = "#client-information";
        link.innerHTML = "Read more <span aria-hidden=\"true\">→</span>";
        card.appendChild(link);
    });
});


/* =========================================================
   DOM READY
   ========================================================= */

document.addEventListener("DOMContentLoaded", () => {

    /* =====================================================
       ELEMENTS
       ===================================================== */

    const preloader = document.getElementById("preloader");
    const siteHeader = document.getElementById("siteHeader");

    const mobileMenuButton =
        document.getElementById("mobileMenuButton");

    const mainNavigation =
        document.getElementById("mainNavigation");

    const informationForm =
        document.getElementById("informationForm");

    const formMessage =
        document.getElementById("formMessage");

    const shareButton =
        document.getElementById("shareButton");

    const currentYear =
        document.getElementById("currentYear");

    const backToTop =
        document.getElementById("backToTop");


    /* =====================================================
       PRELOADER
       ===================================================== */

    const hidePreloader = () => {

        if (!preloader) {
            return;
        }

        preloader.classList.add("hidden");

        setTimeout(() => {
            preloader.style.display = "none";
        }, 750);
    };

    window.addEventListener("load", hidePreloader);

    /* Fallback in case the load event has already fired */
    setTimeout(hidePreloader, 2500);


    /* =====================================================
       HEADER SCROLL EFFECT
       ===================================================== */

    const handleHeaderScroll = () => {

        if (!siteHeader) {
            return;
        }

        if (window.scrollY > 40) {
            siteHeader.classList.add("scrolled");
        } else {
            siteHeader.classList.remove("scrolled");
        }
    };

    window.addEventListener(
        "scroll",
        handleHeaderScroll,
        { passive: true }
    );

    handleHeaderScroll();


    /* =====================================================
       MOBILE MENU
       ===================================================== */

    const closeMobileMenu = () => {

        if (!mobileMenuButton || !mainNavigation) {
            return;
        }

        mobileMenuButton.classList.remove("active");
        mainNavigation.classList.remove("active");

        document.body.classList.remove("menu-open");

        mobileMenuButton.setAttribute(
            "aria-expanded",
            "false"
        );
    };


    const openMobileMenu = () => {

        if (!mobileMenuButton || !mainNavigation) {
            return;
        }

        mobileMenuButton.classList.add("active");
        mainNavigation.classList.add("active");

        document.body.classList.add("menu-open");

        mobileMenuButton.setAttribute(
            "aria-expanded",
            "true"
        );
    };


    if (mobileMenuButton && mainNavigation) {

        mobileMenuButton.setAttribute(
            "aria-expanded",
            "false"
        );

        mobileMenuButton.addEventListener(
            "click",
            () => {

                const isOpen =
                    mainNavigation.classList.contains("active");

                if (isOpen) {
                    closeMobileMenu();
                } else {
                    openMobileMenu();
                }
            }
        );


        /* Close menu when clicking navigation links */

        const navigationLinks =
            mainNavigation.querySelectorAll("a");

        navigationLinks.forEach((link) => {

            link.addEventListener(
                "click",
                () => {
                    closeMobileMenu();
                }
            );

        });


        /* Close menu with Escape key */

        document.addEventListener(
            "keydown",
            (event) => {

                if (event.key === "Escape") {
                    closeMobileMenu();
                }

            }
        );

    }


    /* =====================================================
       SCROLL REVEAL ANIMATION
       ===================================================== */

    const revealElements =
        document.querySelectorAll(".reveal");

    if ("IntersectionObserver" in window) {

        const revealObserver =
            new IntersectionObserver(
                (entries, observer) => {

                    entries.forEach((entry) => {

                        if (!entry.isIntersecting) {
                            return;
                        }

                        entry.target.classList.add("visible");

                        observer.unobserve(entry.target);

                    });

                },
                {
                    threshold: 0.12,
                    rootMargin: "0px 0px -40px 0px"
                }
            );

        revealElements.forEach((element) => {
            revealObserver.observe(element);
        });

    } else {

        /* Fallback for older browsers */

        revealElements.forEach((element) => {
            element.classList.add("visible");
        });

    }


    /* =====================================================
       CURRENT YEAR
       ===================================================== */

    if (currentYear) {
        currentYear.textContent =
            new Date().getFullYear();
    }


    /* =====================================================
       BACK TO TOP
       ===================================================== */

    const handleBackToTop = () => {

        if (!backToTop) {
            return;
        }

        if (window.scrollY > 600) {
            backToTop.classList.add("visible");
        } else {
            backToTop.classList.remove("visible");
        }
    };

    window.addEventListener(
        "scroll",
        handleBackToTop,
        { passive: true }
    );

    handleBackToTop();


    if (backToTop) {

        backToTop.addEventListener(
            "click",
            () => {

                window.scrollTo({
                    top: 0,
                    behavior: "smooth"
                });

            }
        );

    }


    /* =====================================================
       INFORMATION PACKAGE FORM
       ===================================================== */

    if (informationForm) {

        informationForm.addEventListener(
            "submit",
            (event) => {

                event.preventDefault();

                const emailInput =
                    informationForm.querySelector(
                        'input[type="email"]'
                    );

                if (!emailInput) {
                    return;
                }

                const email =
                    emailInput.value.trim();

                if (!email) {

                    if (formMessage) {
                        formMessage.textContent =
                            "Please enter your email address.";
                    }

                    emailInput.focus();

                    return;
                }


                /* Basic email validation */

                const emailPattern =
                    /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

                if (!emailPattern.test(email)) {

                    if (formMessage) {
                        formMessage.textContent =
                            "Please enter a valid email address.";
                    }

                    emailInput.focus();

                    return;
                }


                /*
                 * Front-end confirmation.
                 *
                 * No email service/backend has been connected yet,
                 * so this does not pretend to send an actual email.
                 */

                if (formMessage) {

                    formMessage.textContent =
                        "Thank you. Your request has been received. The information package delivery service will be connected here.";

                }


                emailInput.value = "";


                /*
                 * Store the request locally so the site can
                 * remember that the visitor submitted the form.
                 */

                try {

                    localStorage.setItem(
                        "perennialBridgeInformationRequest",
                        JSON.stringify({
                            email: email,
                            submittedAt:
                                new Date().toISOString()
                        })
                    );

                } catch (error) {

                    /* Ignore localStorage errors */

                }

            }
        );

    }


    /* =====================================================
       SHARE BUTTON
       ===================================================== */

    if (shareButton) {

        shareButton.addEventListener(
            "click",
            async () => {

                const shareData = {
                    title:
                        "The Perennial Bridge Initiative",

                    text:
                        "Explore The Perennial Bridge Initiative — an interfaith ordination programme focused on spiritual formation, the Mature Gospel, and ministry.",

                    url:
                        window.location.href
                };


                /* -----------------------------------------
                   NATIVE SHARE
                   ----------------------------------------- */

                if (
                    navigator.share &&
                    typeof navigator.share === "function"
                ) {

                    try {

                        await navigator.share(
                            shareData
                        );

                        return;

                    } catch (error) {

                        /*
                         * User may simply have cancelled
                         * the native share window.
                         */

                        if (
                            error &&
                            error.name ===
                            "AbortError"
                        ) {
                            return;
                        }

                    }

                }


                /* -----------------------------------------
                   CLIPBOARD FALLBACK
                   ----------------------------------------- */

                try {

                    if (
                        navigator.clipboard &&
                        typeof navigator.clipboard.writeText ===
                        "function"
                    ) {

                        await navigator.clipboard.writeText(
                            window.location.href
                        );

                        showTemporaryShareMessage(
                            "Link copied"
                        );

                        return;
                    }

                } catch (error) {

                    /* Continue to fallback */

                }


                /* -----------------------------------------
                   OLD BROWSER FALLBACK
                   ----------------------------------------- */

                const temporaryInput =
                    document.createElement("input");

                temporaryInput.value =
                    window.location.href;

                temporaryInput.style.position =
                    "fixed";

                temporaryInput.style.opacity =
                    "0";

                document.body.appendChild(
                    temporaryInput
                );

                temporaryInput.select();

                try {

                    document.execCommand("copy");

                    showTemporaryShareMessage(
                        "Link copied"
                    );

                } catch (error) {

                    showTemporaryShareMessage(
                        "Copy the page link from your browser"
                    );

                }

                document.body.removeChild(
                    temporaryInput
                );

            }
        );

    }


    /* =====================================================
       SHARE BUTTON MESSAGE
       ===================================================== */

    function showTemporaryShareMessage(message) {

        if (!shareButton) {
            return;
        }

        const originalHTML =
            shareButton.innerHTML;

        shareButton.innerHTML =
            `<i class="fa-solid fa-check"></i> ${message}`;

        shareButton.disabled = true;

        setTimeout(() => {

            shareButton.innerHTML =
                originalHTML;

            shareButton.disabled = false;

        }, 2200);

    }


    /* =====================================================
       SMOOTH INTERNAL NAVIGATION
       ===================================================== */

    const internalLinks =
        document.querySelectorAll(
            'a[href^="#"]'
        );

    internalLinks.forEach((link) => {

        link.addEventListener(
            "click",
            (event) => {

                const targetID =
                    link.getAttribute("href");

                if (
                    !targetID ||
                    targetID === "#"
                ) {
                    return;
                }

                const target =
                    document.querySelector(targetID);

                if (!target) {
                    return;
                }

                event.preventDefault();

                const headerHeight =
                    siteHeader
                        ? siteHeader.offsetHeight
                        : 0;

                const targetPosition =
                    target.getBoundingClientRect().top +
                    window.scrollY -
                    headerHeight;

                window.scrollTo({
                    top: targetPosition,
                    behavior: "smooth"
                });

            }
        );

    });


    /* =====================================================
       RESIZE HANDLING
       ===================================================== */

    window.addEventListener(
        "resize",
        () => {

            /*
             * If the screen becomes large again,
             * make sure the mobile menu is reset.
             */

            if (
                window.innerWidth > 850
            ) {
                closeMobileMenu();
            }

        }
    );


    /* =====================================================
       FORM INPUT CLEANUP
       ===================================================== */

    if (informationForm) {

        const emailInput =
            informationForm.querySelector(
                'input[type="email"]'
            );

        if (emailInput && formMessage) {

            emailInput.addEventListener(
                "input",
                () => {

                    if (
                        formMessage.textContent
                    ) {
                        formMessage.textContent =
                            "";
                    }

                }
            );

        }

    }


    /* =====================================================
       FINAL WORD READ MORE
       ===================================================== */

    const finalWordContent =
        document.querySelector(".final-word-content");

    if (finalWordContent) {

        const finalWordParagraphs =
            finalWordContent.querySelectorAll("p");

        finalWordParagraphs.forEach((paragraph, index) => {

            if (index > 0) {
                paragraph.classList.add("final-word-extra");
            }

        });

        const readMoreButton =
            document.createElement("button");

        readMoreButton.type = "button";
        readMoreButton.className = "read-more-button";
        readMoreButton.setAttribute("aria-expanded", "false");
        readMoreButton.textContent = "Read more";

        const finalSymbol =
            finalWordContent.querySelector(".final-symbol");

        if (finalSymbol) {
            finalWordContent.insertBefore(
                readMoreButton,
                finalSymbol
            );
        } else {
            finalWordContent.appendChild(readMoreButton);
        }

        readMoreButton.addEventListener("click", () => {

            const isExpanded =
                finalWordContent.classList.toggle("is-expanded");

            readMoreButton.setAttribute(
                "aria-expanded",
                String(isExpanded)
            );

            readMoreButton.textContent =
                isExpanded ? "Read less" : "Read more";

        });

    }

});
document.addEventListener("DOMContentLoaded",function(){var m=document.querySelector("body > main");if(!m)return;m.className="client-revision-main";m.innerHTML=`<section class="client-box client-box-dark"><div class="container client-narrow"><p class="client-eyebrow">THE PERENNIAL BRIDGE INITIATIVE LIMITED</p><h1>Building Bridges Across Faiths and Philosophies</h1><p class="client-display">Do You Sense That Beneath All Religions There Is One Truth?</p><p class="client-display">If You Have Ever Longed for a Wisdom Deeper Than Doctrine - You Have Found Your Home</p><p>You have felt it.</p><p>That quiet hunger that no amount of information can satisfy. Beneath daily life there is something more. Something real. Something sacred.</p></div></section><section class="client-box client-box-light"><div class="container client-narrow"><p>Perhaps you have sat in a church pew, read Rumi, practiced meditation, or studied the mystics of Christian, Muslim, Hindu, Buddhist, Jewish, and Taoist traditions and noticed they seem to describe the same journey.</p><a class="client-link" href="#welcome">Learn more -></a><p>You are not imagining it. The mystics speak with one voice: the separate self is an illusion, separation from the Divine is the root of suffering, and conscious union is possible. This is the Perennial Philosophy - the wisdom The Perennial Bridge Initiative exists to share.</p></div></section><section class="client-box client-box-dark" id="welcome"><div class="container client-narrow"><p class="client-eyebrow">WELCOME</p><h2>Welcome to The Perennial Bridge Initiative</h2><p class="client-display">A Global School of Perennial Wisdom for Seekers of All Faiths and No Faith</p><p>We are a neutral, interfaith educational platform making perennial wisdom accessible regardless of your background or beliefs. Christian mystic, Muslim Sufi, Hindu Vedantin, Buddhist practitioner, Jewish Kabbalist, Taoist sage, secular seeker, or no tradition at all - you are welcome here.</p></div></section><section class="client-box client-box-light"><div class="container client-narrow"><p class="client-eyebrow">WHAT MAKES US DIFFERENT</p><h2>What Makes Us Different</h2><div class="client-feature-grid"><article><h3>We Honour All Traditions</h3><p>We study the Upanishads alongside the Gospel of Thomas, Rumi alongside Meister Eckhart, and the Tao Te Ching alongside the Zohar. We drink from every well.</p></article><article><h3>We Prioritise Practice Over Theory</h3><p>We practice meditation, contemplation, prayer, and silence - the disciplines that lead to direct knowing.</p><a class="client-link" href="#pathways">Learn more -></a></article><article><h3>We Are Open to Everyone</h3><p>You need no prior qualifications. You need only a sincere desire to seek the truth.</p></article><article><h3>We Are Accessible and Affordable</h3><p>Our programmes are online and accessible anywhere. Fees are modest, and financial aid is available.</p></article></div></div></section><section class="client-box client-box-dark" id="pathways"><div class="container"><div class="client-narrow"><p class="client-eyebrow">OUR PROGRAMMES</p><h2>Four Pathways to Wisdom and Service</h2><p>Each certification pathway meets you where you are and takes you where you long to go.</p></div><div class="client-pathways"><article class="client-pathway"><span class="client-number">01</span><h3>Diploma in Perennial Philosophy and Mystical Studies</h3><p class="client-display">Your Foundation in the Perennial Wisdom</p><p>Duration: Twelve Months. Prerequisite: None. Explore the world's mystical traditions through study, practice, community, mentorship, and a final project.</p><a class="client-link" href="#information">Learn more -></a><p>Upon completion: Dip.PPMS.</p></article><article class="client-pathway"><span class="client-number">02</span><h3>Professional Diploma in Interfaith Dialogue and Counseling</h3><p class="client-display">For Those Called to Build Bridges and Heal Divides</p><p>Duration: Twelve Months. Train in dialogue, comparative religion, peacebuilding, and pastoral counseling.</p><a class="client-link" href="#information">Learn more -></a><p>Upon completion: Prof.Dip.IFDC.</p></article><article class="client-pathway"><span class="client-number">03</span><h3>Professional Diploma in Spiritual Psychology and Counseling</h3><p class="client-display">For Those Called to Accompany Others on the Journey of Healing</p><p>Duration: Twelve Months. Integrate perennial philosophy with contemporary psychology and develop practical counseling skills.</p><a class="client-link" href="#information">Learn more -></a><p>Upon completion: Prof.Dip.SPC.</p></article><article class="client-pathway"><span class="client-number">04</span><h3>Advanced Diploma in Perennial Philosophy</h3><p class="client-display">For Those Called to Teach, Write, and Lead</p><p>Duration: Twelve to Eighteen Months. Pursue specialised study, electives, and an original research project.</p><a class="client-link" href="#information">Learn more -></a><p>Upon completion: Adv.Dip.PP.</p></article></div></div></section><section class="client-box client-box-light"><div class="container client-narrow"><p class="client-eyebrow">YOUR JOURNEY, YOUR PACE</p><h2>Your Journey, Your Pace</h2><p>Begin with the Diploma, then follow the pathway that fits your calling: interfaith leadership, spiritual counseling, or advanced teaching and research. Whatever your path, you will be supported by mentors and transformed by the wisdom of the ages.</p></div></section><section class="client-box client-box-dark"><div class="container client-narrow"><p class="client-eyebrow">WHAT OUR STUDENTS SAY</p><h2>What Our Students Say</h2><div class="client-testimonials"><blockquote>I came seeking knowledge. I found wisdom. I came alone. I found a community.<cite>- Sarah M., Christian contemplative</cite></blockquote><blockquote>The Perennial Bridge honours all traditions. It has deepened my faith and opened my eyes to others.<cite>- Ahmed K., Sufi practitioner</cite></blockquote><blockquote>I found a rigorous, open, and transformative exploration of meaning.<cite>- David L., secular seeker</cite></blockquote><blockquote>Now I know I am part of a great cloud of witnesses.<cite>- Priya R., Hindu seeker</cite></blockquote></div></div></section><section class="client-box client-box-light" id="information"><div class="container client-narrow"><p class="client-eyebrow">BEGIN YOUR JOURNEY TODAY</p><h2>The path is open. The door is unlocked.</h2><p>Request the complete curriculum, programme information, tuition, application process, and our introductory e-book, The One Voice.</p><form class="client-form"><label for="client-email">Enter Your Email Address:</label><input id="client-email" type="email" required placeholder="you@example.com"><button class="btn btn-primary" type="submit">Send Me the Complete Information Package</button><small>We will never share your email address or spam you.</small></form><h3>Recommend Us to Friends and Family</h3><p>Share this page with someone seeking something deeper.</p></div></section><section class="client-box client-box-dark"><div class="container client-narrow"><p class="client-eyebrow">A FINAL WORD</p><h2>The mystics of the world have spoken.</h2><p>They have told us that union is possible - here and now, in this very life. We promise a rigorous journey, a community of fellow seekers, and mentors who will accompany you on the way.</p><p class="client-display">If you seek with all your heart, you will find. The One who calls you is faithful.</p></div></section><section class="client-box client-box-light"><div class="container client-narrow"><p class="client-eyebrow">INTERFAITH ORDINATION PROGRAMME</p><h2>The Perennial Bridge Ordination</h2><p class="client-display">Ordination is the Exodus of the Soul</p><p class="client-display">Awaken the Mature Gospel. Transform Lives. Forge Your Ministry.</p><p>A two-year, non-denominational ordination programme forming ministers who read Scripture as the living map of human consciousness and lead others from literalism into transcendent truth.</p><h3>The Call</h3><p>The world needs awakened leaders who understand that the Kingdom is within.</p><a class="client-link" href="#information">Learn more -></a><h3>The Curriculum: Your Journey to Wholeness</h3><p>A progressive revelation from existential crisis to self-realisation, from the dark night of the soul to the dawn of wholeness.</p></div></section>`;var f=m.querySelector("form");if(f)f.addEventListener("submit",function(e){e.preventDefault();alert("Thank you. Your request has been received.");f.reset()})});document.addEventListener("DOMContentLoaded",function(){document.querySelectorAll("body > main").forEach(function(x,i){if(i>0)x.style.display="none"})});document.addEventListener("DOMContentLoaded",function(){var oldForm=document.querySelector(".client-form");if(!oldForm)return;var form=oldForm.cloneNode(true);oldForm.replaceWith(form);form.addEventListener("submit",function(event){event.preventDefault();var input=form.querySelector("input[type=email]");var email=input?input.value.trim():"";if(!email||!input.checkValidity()){if(input)input.reportValidity();return}var message="Hello The Perennial Bridge Initiative, I would like to receive the complete information package. My email address is: "+email;window.open("https://wa.me/2347065445548?text="+encodeURIComponent(message),"_blank","noopener,noreferrer")})});document.addEventListener("DOMContentLoaded",function(){var main=document.querySelector("body > main");if(!main)return;var sections=main.querySelectorAll(".client-box");if(sections[0])sections[0].id="home";var welcome=main.querySelector("#welcome");if(welcome)welcome.id="about";var pathways=main.querySelector("#pathways");var info=main.querySelector("#information");var targets={Home:"#home",About:"#about","Global Leadership":"#pathways","The Call":"#ordination","Programmes":"#pathways","The Journey":"#journey",Contact:"#contact","Apply / Enquire":"#information"};var ordination=[...sections].find(function(s){return s.textContent.indexOf("INTERFAITH ORDINATION PROGRAMME")>-1});if(ordination)ordination.id="ordination";var journey=[...sections].find(function(s){return s.textContent.indexOf("YOUR JOURNEY, YOUR PACE")>-1});if(journey)journey.id="journey";document.querySelectorAll(".main-navigation a,.footer-column a,.brand").forEach(function(link){var label=link.textContent.trim();if(targets[label])link.setAttribute("href",targets[label]);});document.querySelectorAll('a[href^="#"]').forEach(function(link){link.addEventListener("click",function(e){var id=link.getAttribute("href");var target=document.querySelector(id);if(!target)return;e.preventDefault();target.scrollIntoView({behavior:"smooth",block:"start"});document.body.classList.remove("menu-open");})})});document.addEventListener("DOMContentLoaded",function(){document.querySelectorAll('a[href="#welcome"]').forEach(function(a){a.href="#about"});document.querySelectorAll('a[href="#programme"]').forEach(function(a){a.href="#pathways"});});
document.addEventListener("DOMContentLoaded",function(){var main=document.querySelector("body > main");if(!main||main.querySelector("#sponsorship"))return;var journey=[...main.querySelectorAll(".client-box")].find(function(section){return section.textContent.indexOf("YOUR JOURNEY, YOUR PACE")>-1});if(!journey)return;journey.insertAdjacentHTML("afterend",`<section class="client-box client-box-dark" id="sponsorship"><div class="container"><div class="client-narrow"><p class="client-eyebrow">PARTNER WITH THE BRIDGE</p><h2>Help Make Wisdom Accessible</h2><p class="client-display">Your support can open the door for the next seeker.</p><p>We are building an accessible, interfaith school of perennial wisdom. Sponsorship helps us provide scholarships, strengthen our learning resources, and welcome students who would otherwise be unable to participate.</p></div><div class="client-pathways"><article class="client-pathway"><span class="client-number">01</span><h3>Sponsor a Learner</h3><p>Help a sincere student access study, mentorship, and a transformative community.</p></article><article class="client-pathway"><span class="client-number">02</span><h3>Support the School</h3><p>Help fund curriculum development, digital resources, and the work of building bridges across traditions.</p></article><article class="client-pathway"><span class="client-number">03</span><h3>Become a Partner</h3><p>Explore an ongoing relationship with an initiative committed to wisdom, service, and interfaith understanding.</p></article></div><a class="client-link" href="https://wa.me/2347065445548?text=Hello%20The%20Perennial%20Bridge%20Initiative%2C%20I%20would%20like%20to%20discuss%20sponsorship." target="_blank" rel="noopener noreferrer">Discuss sponsorship -></a></div></section>`);});

/* Motion layer: reveal sections on scroll and stagger their card entrances. */
document.addEventListener("DOMContentLoaded", function () {
    var sections = document.querySelectorAll("body > main:first-of-type .client-box");
    if (!sections.length) return;

    sections.forEach(function (section) {
        section.querySelectorAll(".client-feature-grid > article, .client-pathways > .client-pathway, .client-testimonials > blockquote").forEach(function (card, index) {
            card.style.setProperty("--card-delay", Math.min(index * 90, 360) + "ms");
        });
    });

    if (!("IntersectionObserver" in window) || window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
        sections.forEach(function (section) { section.classList.add("is-visible"); });
        return;
    }

    var observer = new IntersectionObserver(function (entries, instance) {
        entries.forEach(function (entry) {
            if (!entry.isIntersecting) return;
            entry.target.classList.add("is-visible");
            instance.unobserve(entry.target);
        });
    }, { threshold: 0.12, rootMargin: "0px 0px -8%" });

    sections.forEach(function (section) { observer.observe(section); });
});

/* Connect the visible client enquiry form to the local backend API. */
document.addEventListener("submit", async function (event) {
    var form = event.target.closest(".client-form");
    if (!form) return;

    event.preventDefault();
    event.stopImmediatePropagation();

    var input = form.querySelector('input[type="email"]');
    var button = form.querySelector('button[type="submit"]');
    if (!input || !input.checkValidity()) {
        if (input) input.reportValidity();
        return;
    }

    var originalLabel = button ? button.textContent : "Send request";
    var status = form.querySelector(".client-form-status");
    if (!status) {
        status = document.createElement("small");
        status.className = "client-form-status";
        form.appendChild(status);
    }

    if (button) {
        button.disabled = true;
        button.textContent = "Sending...";
    }
    status.textContent = "";

    try {
        var response = await fetch("http://127.0.0.1:3000/api/information-requests", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email: input.value.trim(), source: "website-information-form" }),
        });
        var result = await response.json();

        if (!response.ok) throw new Error(result.message || "Unable to submit your request.");

        status.textContent = "Thank you. Your information request has been received.";
        status.dataset.state = "success";
        form.reset();
    } catch (error) {
        status.textContent = "We could not connect to the information service. Please try again or contact us on WhatsApp.";
        status.dataset.state = "error";
        console.error("Information request failed:", error);
    } finally {
        if (button) {
            button.disabled = false;
            button.textContent = originalLabel;
        }
    }
}, true);

/* The visible client revision uses #client-information; avoid the hidden legacy form target. */
document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll(".main-navigation a, .nav-cta").forEach(function (link) {
        if (link.textContent.trim() === "Apply / Enquire") {
            link.setAttribute("href", "#client-information");
        }
    });
});
